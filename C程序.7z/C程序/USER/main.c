#include "my_include.h"

char dis0[25]; 
char dis1[25]; 
u16 adcx;
#define F_SIZE 16
#define MyLCD_Show(m, n, p) LCD_ShowString(LCD_GetPos_X(F_SIZE, m), LCD_GetPos_Y(F_SIZE, n), p, F_SIZE, false)

extern u16 ADC_convered[5]; 
float temp[5];
float value;
float value1;
char buf[5];
char buf1[5];

#define RONGCHAZHI_UD 100 
#define RONGCHAZHI_LR 100 

#define ZHUANDONG_ZZ 30	 
#define ZHUANDONG_FZ -30 

int lighVla_left = 0;  
int lighVla_up = 0;	   
int lighVla_right = 0; 
int lighVla_down = 0;  
float batteryVolt = 0; 
float BatCap = 80;	   

unsigned char disFlag = 0;		   
unsigned char setMode = 0;		   
unsigned char rememberMode = 0xff; 

int main(void)
{
	unsigned char disYplace = 0; 
	Adc_Init();			 
	My_KEY_Init();		
	My_StepMotor_Init(); 
	LCD_Init(); 
	LCD_Clear(Color16_BLACK); 
	BACK_COLOR = Color16_BLACK;
	FRONT_COLOR = Color16_LIGHTGRAY;
	disYplace = 0;								
	MyLCD_Show(2, disYplace++, "˫��׷��ϵͳ"); 
	FRONT_COLOR = Color16_LIGHTBLUE;
	MyLCD_Show(1, disYplace++, "���ղ���: "); 
	MyLCD_Show(4, disYplace++, "��: ");		  
	MyLCD_Show(1, disYplace, "��: ");		  
	MyLCD_Show(9, disYplace++, "��: ");		  
	MyLCD_Show(4, disYplace++, "��: ");		  
	MyLCD_Show(1, disYplace++, "����: ");	  

	while (1)
	{
		My_KeyScan(); 
		if (KeyIsPress(KEY_5))
		{
			setMode++;
			if (setMode >= 2)
				setMode = 0; 
		}

		switch (setMode)
		{
		case 1: 

			if ((lighVla_left - lighVla_right) > RONGCHAZHI_LR) 
			{
				My_StepMotor_RotateAngle(0, ZHUANDONG_FZ);
			}
			else if ((lighVla_right - lighVla_left) > RONGCHAZHI_LR) 
			{
				My_StepMotor_RotateAngle(0, ZHUANDONG_ZZ);
			}
			else
			{
				My_StepMotor_Stop(0);
			}

			if ((lighVla_up - lighVla_down) > RONGCHAZHI_UD) 
			{
				My_StepMotor_RotateAngle(1, ZHUANDONG_FZ);
			}
			else if ((lighVla_down - lighVla_up) > RONGCHAZHI_UD) 
			{
				My_StepMotor_RotateAngle(1, ZHUANDONG_ZZ);
			}
			else
			{
				My_StepMotor_Stop(1);
			}
			break;
		
		case 0:						 
			if (KeyIsPressed(KEY_2)) 
			{
				My_StepMotor_RotateAngle(0, ZHUANDONG_ZZ); 
			}
			else if (KeyIsPressed(KEY_4)) 
			{
				My_StepMotor_RotateAngle(0, ZHUANDONG_FZ); 
			}
			else
			{
				My_StepMotor_Stop(0);
			}

			if (KeyIsPressed(KEY_1)) 
			{
				My_StepMotor_RotateAngle(1, ZHUANDONG_ZZ); 
			}
			else if (KeyIsPressed(KEY_3)) 
			{
				My_StepMotor_RotateAngle(1, ZHUANDONG_FZ); 
			}
			else
			{
				My_StepMotor_Stop(1);
			}
			break;
		default:
			break;
		}

		lighVla_left = 1000 * (float)ADC_convered[0] / 4096;  
		lighVla_up = 1000 * (float)ADC_convered[1] / 4096;	  
		lighVla_right = 1000 * (float)ADC_convered[2] / 4096; 
		lighVla_down = 1000 * (float)ADC_convered[3] / 4096;  

		if (disFlag == 1) 
		{
			disFlag = 0;
			FRONT_COLOR = Color16_LIGHTBLUE;
			disYplace = 2;						  
			sprintf(dis0, "��:%d  ", lighVla_up); 
			MyLCD_Show(4, disYplace++, dis0);	  

			sprintf(dis0, "%d ", lighVla_left);	 
			MyLCD_Show(4, disYplace, dis0);		 
			sprintf(dis0, "%d ", lighVla_right); 
			MyLCD_Show(12, disYplace++, dis0);	 

			sprintf(dis0, "%d ", lighVla_down); 
			MyLCD_Show(7, disYplace++, dis0);	
			if (rememberMode != setMode)
			{
				rememberMode = setMode; 
				if (setMode == 0)
					MyLCD_Show(8, disYplace++, "�ֶ� "); 
				else if (setMode == 1)
					MyLCD_Show(8, disYplace++, "�Զ�  "); 
			}

			adcx = (float)ADC_convered[4];
			batteryVolt = (float)adcx * (3.3 / 4096 * 2); 
			if (batteryVolt > 4.15)
			{
				BatCap = 0.99;
			}
			else if (batteryVolt < 3.4)
			{
				BatCap = 0;
			}
			else
			{
				BatCap = (batteryVolt - 3.4) / (4.15 - 3.4);
			} 

			if (batteryVolt < 0.30)
			{
				FRONT_COLOR = Color16_RED;
			}
			sprintf(dis0, "B:%3.1fv Q:%02d%% ", batteryVolt, (int)(BatCap * 100)); 
			MyLCD_Show(1, 6, dis0); 
		}
	}
}
