#include "my_stepmotor.h"

int32 location_now[ArrayCount(LINES_MOTOR_STEP)];
int32 location_aim[ArrayCount(LINES_MOTOR_STEP)];
StepMotorState motorState[ArrayCount(LINES_MOTOR_STEP)];

void Step_AA(u8 ch)
{
	PinOut(LINES_MOTOR_STEP[ch][0])=LINE_ON;
	PinOut(LINES_MOTOR_STEP[ch][1])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][2])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][3])=LINE_OFF;
}
void Step_AB(u8 ch)
{
	PinOut(LINES_MOTOR_STEP[ch][0])=LINE_ON;
	PinOut(LINES_MOTOR_STEP[ch][1])=LINE_ON;
	PinOut(LINES_MOTOR_STEP[ch][2])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][3])=LINE_OFF;
}
void Step_BB(u8 ch)
{
	PinOut(LINES_MOTOR_STEP[ch][0])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][1])=LINE_ON;
	PinOut(LINES_MOTOR_STEP[ch][2])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][3])=LINE_OFF;
}
void Step_BC(u8 ch)
{
	PinOut(LINES_MOTOR_STEP[ch][0])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][1])=LINE_ON;
	PinOut(LINES_MOTOR_STEP[ch][2])=LINE_ON;
	PinOut(LINES_MOTOR_STEP[ch][3])=LINE_OFF;
}
void Step_CC(u8 ch)
{
	PinOut(LINES_MOTOR_STEP[ch][0])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][1])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][2])=LINE_ON;
	PinOut(LINES_MOTOR_STEP[ch][3])=LINE_OFF;
}
void Step_CD(u8 ch)
{
	PinOut(LINES_MOTOR_STEP[ch][0])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][1])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][2])=LINE_ON;
	PinOut(LINES_MOTOR_STEP[ch][3])=LINE_ON;
}
void Step_DD(u8 ch)
{
	PinOut(LINES_MOTOR_STEP[ch][0])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][1])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][2])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][3])=LINE_ON;
}
void Step_DA(u8 ch)
{
	PinOut(LINES_MOTOR_STEP[ch][0])=LINE_ON;
	PinOut(LINES_MOTOR_STEP[ch][1])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][2])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][3])=LINE_ON;
}
void Step_OFF(u8 ch)
{
	PinOut(LINES_MOTOR_STEP[ch][0])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][1])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][2])=LINE_OFF;
	PinOut(LINES_MOTOR_STEP[ch][3])=LINE_OFF;
}

void My_StepMotor_Init(void)
{
	u8 i;	
	for(i=0;i<ArrayCount(LINES_MOTOR_STEP);i++)
	{
#if	!defined (USE_HAL_DRIVER)
		GPIO_Pin_Init(LINES_MOTOR_STEP[i][0],GPIO_Mode_Out_PP);
		GPIO_Pin_Init(LINES_MOTOR_STEP[i][1],GPIO_Mode_Out_PP);
		GPIO_Pin_Init(LINES_MOTOR_STEP[i][2],GPIO_Mode_Out_PP);
		GPIO_Pin_Init(LINES_MOTOR_STEP[i][3],GPIO_Mode_Out_PP);
#else
		GPIO_Pin_Init(LINES_MOTOR_STEP[i][0],GPIO_MODE_OUTPUT_PP,GPIO_PULLUP);
		GPIO_Pin_Init(LINES_MOTOR_STEP[i][1],GPIO_MODE_OUTPUT_PP,GPIO_PULLUP);
		GPIO_Pin_Init(LINES_MOTOR_STEP[i][2],GPIO_MODE_OUTPUT_PP,GPIO_PULLUP);
		GPIO_Pin_Init(LINES_MOTOR_STEP[i][3],GPIO_MODE_OUTPUT_PP,GPIO_PULLUP);
#endif
		Step_AA(i);
		DelayMs(1);
		Step_AB(i);
		DelayMs(1);
		Step_BB(i);
		DelayMs(1);
		Step_BC(i);
		DelayMs(1);
		Step_BB(i);
		DelayMs(1);
		Step_AB(i);
		DelayMs(1);
		Step_AA(i);
		Step_OFF(i);
		location_now[i] = 0;
		location_aim[i] = 0;
		motorState[i] = StepMotor_Stop;
	}	
}

void My_StepMotor_WalkOneStep(u8 ch)
{
	u8 state = 0;

	if(location_now[ch]==location_aim[ch])
	{
		My_StepMotor_Stop(ch);
		motorState[ch] = StepMotor_Stop;
		return;
	}
	state = (location_now[ch]%8 + 8)%8;
	switch(state)
	{
		case 0:Step_AB(ch);break;
		case 1:Step_BB(ch);break;
		case 2:Step_BC(ch);break;
		case 3:Step_CC(ch);break;
		case 4:Step_CD(ch);break;
		case 5:Step_DD(ch);break;
		case 6:Step_DA(ch);break;
		case 7:Step_AA(ch);break;
	} 
	if(location_now[ch]<location_aim[ch])
	{   
		location_now[ch]++;
		motorState[ch] = StepMotor_Forward;
	}
		if(location_now[ch]>location_aim[ch])
	{   
		location_now[ch]--;
		motorState[ch] = StepMotor_Backward;
	}
	
}

void My_StepMotor_RotateStep(u8 ch, int32 step)
{
	location_aim[ch] = location_now[ch] + step;
	My_StepMotor_GetState(ch);
}

void My_StepMotor_RotateStepAdd(u8 ch, int32 step)
{
	location_aim[ch] +=  step;
	My_StepMotor_GetState(ch);
}

void My_StepMotor_RotateToLocation(u8 ch, int32 location)
{
	location_aim[ch] = location;
	My_StepMotor_GetState(ch);
}
void My_StepMotor_RotateAngle(u8 ch, double angle)
{
	angle *= 64; 
	My_StepMotor_RotateStep(ch,angle/5.625f);
}

void My_StepMotor_RotateAngleAdd(u8 ch, double angle)
{
	angle *= 64; 
	My_StepMotor_RotateStepAdd(ch,angle/5.625f);
}

void My_StepMotor_RotateToAngle(u8 ch, double angle)
{
	angle *= 64; 
	My_StepMotor_RotateToLocation(ch,angle/5.625f);
}

void My_StepMotor_Go(void)
{
	uint8_t ch;	
	for(ch=0;ch<ArrayCount(LINES_MOTOR_STEP);ch++)
	{
		My_StepMotor_WalkOneStep(ch);
	}
}	

void My_StepMotor_Stop(u8 ch)
{
	location_aim[ch] = location_now[ch];
	Step_OFF(ch);
	
}			

int32 My_StepMotor_GetCurrentLocation(u8 ch)
{
	return location_now[ch];
}	

int32 My_StepMotor_GetAimLocation(u8 ch)
{
	return location_aim[ch];
}		

StepMotorState My_StepMotor_GetState(u8 ch)
{
	if(location_now[ch]<location_aim[ch])
	{   
		motorState[ch] = StepMotor_Forward;
	}
	else if(location_now[ch]>location_aim[ch])
	{		
		motorState[ch] = StepMotor_Backward;
	}
	
	return motorState[ch];
}
