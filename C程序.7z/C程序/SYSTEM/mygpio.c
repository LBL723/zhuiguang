#include "mygpio.h"

void MyGPIO_ClockEnable(MyPinDef pin)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA<<(pin/16), ENABLE);  
}

void GPIO_Pin_Init(MyPinDef pin,GPIOMode_TypeDef Mode){
	GPIO_InitTypeDef GPIO_InitStructure;   
	MyGPIO_ClockEnable(pin);
	GPIO_InitStructure.GPIO_Pin  = 0x0001<<(pin%16); 
	GPIO_InitStructure.GPIO_Mode = Mode;  
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	if(pin==PB3 || pin==PB4 || pin==PA15)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);	
		GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
	}
	else if(pin==PA13 || pin==PA14)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);	
		GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable,ENABLE);
	}
	else if(pin==PC13)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE );
		PWR_BackupAccessCmd( ENABLE );
		BKP_TamperPinCmd(DISABLE);  
		PWR_BackupAccessCmd(DISABLE);
		
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz; 
	}
	else if(pin==PC14 || pin==PC15)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE );
		PWR_BackupAccessCmd( ENABLE );
		RCC_LSEConfig( RCC_LSE_OFF ); 
		PWR_BackupAccessCmd(DISABLE);
		
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz; 
	}
	else if(pin==PD0 || pin==PD1)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
        GPIO_PinRemapConfig(GPIO_Remap_PD01, ENABLE);
	}
	GPIO_Init(((GPIO_TypeDef *) (GPIOA_BASE+0x0400*(pin/16))), &GPIO_InitStructure);
}


void GPIO_WriteHigh(GPIO_TypeDef* GPIOx,u8 dat)
{
	GPIOx->BRR = 0xff00;
	GPIOx->BSRR = dat<<8;
}

void GPIO_WriteLow(GPIO_TypeDef* GPIOx,u8 dat)
{
	GPIOx->BRR = 0x00ff;
	GPIOx->BSRR = dat;
}


