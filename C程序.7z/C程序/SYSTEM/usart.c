#include "usart.h"	 
  
#if 1
#if !defined ( __GNUC__ ) || defined (__CC_ARM) 
#pragma import(__use_no_semihosting)             
               
struct __FILE 
{ 
	int handle; 

}; 
#endif

FILE __stdout;       
  
void _sys_exit(int x) 
{ 
	x = x; 
} 
USART_TypeDef* USART_Printf = USART1;

int fputc(int ch, FILE *f)
{      
	USARTSendByte(USART_Printf,ch);     
	return ch;
}
#endif 
  
void SetPrintfUSART(USART_TypeDef* USARTx)
{
	USART_Printf = USARTx;
}
USART_TypeDef* GetPrintfUSART(void)
{
	return USART_Printf;
}
void USARTSendByte(USART_TypeDef* USARTx, uint8_t dat)
{
	while((USARTx->SR&USART_SR_TC)==0);  

	USART_SendData(USARTx,dat);
}
void USARTSendBytes(USART_TypeDef* USARTx, const uint8_t *dat, uint16_t length)
{
	while(length--)
	{
	  USARTSendByte(USARTx,*dat);
	  dat++;
	}
}
  
void USARTSendString(USART_TypeDef* USARTx, const char *str)
{
	while(*str!='\0'){
		USARTSendByte(USARTx,*str);
		str++;
	}
}

void USARTx_Init(USART_TypeDef* USARTx, u32 baud)
{
	
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	if(USARTx == USART1)
	{
#if EN_USART1   
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);	
		
		GPIO_Pin_Init(PA9,GPIO_Mode_AF_PP);
	
		GPIO_Pin_Init(PA10,GPIO_Mode_IN_FLOATING);
		
		NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;		
#endif
	}
#if EN_USART2   
	else if(USARTx == USART2)
	{
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);	
		
		GPIO_Pin_Init(PA2,GPIO_Mode_AF_PP);
	
		GPIO_Pin_Init(PA3,GPIO_Mode_IN_FLOATING);
		
		NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		
	}
#endif	
#if EN_USART3   
	else if(USARTx == USART3)
	{
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);	
		
		GPIO_Pin_Init(PB10,GPIO_Mode_AF_PP);
	
		GPIO_Pin_Init(PB11,GPIO_Mode_IN_FLOATING);
		
		NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;		
	}
#endif	

	USART_InitStructure.USART_BaudRate = baud;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	

	USART_DeInit(USARTx);  
	USART_Init(USARTx, &USART_InitStructure); 
#if USART1_IT_RXNE>0
	USART_ITConfig(USARTx, USART_IT_RXNE, ENABLE);
#endif
#if USART1_IT_TXE>0
	USART_ITConfig(USARTx, USART_IT_TXE, ENABLE);
#endif
#if USART1_IT_IDLE>0
	USART_ITConfig(USARTx, USART_IT_IDLE, ENABLE);

	USART_DMACmd(USART1,USART_DMAReq_Rx,ENABLE);
 	My_DMA_Config(DMA1_Channel5,DMA_DIR_PeripheralSRC,(u32)(&USART1->DR),(u32)USART1_RX_Buff,ArrayCount(USART1_RX_Buff));//DMA1ͨ��4,����Ϊ����1,�洢��ΪSendBuff,����SEND_BUF_SIZE.
#endif
	USART_Cmd(USARTx, ENABLE);                    
}

#if USART1_IT_IDLE>0
u8 USART1_RX_Buff[RX_Buff_LEN];	
u8 readBuffer[RX_Buff_LEN];
bool readMsgFlag;
#endif
#if EN_USART1   
void USART1_IRQHandler(void)                	
{
	u8 Res;
#if USART1_IT_RXNE>0
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)  
	{
		Res = USART_ReceiveData(USART1);	
		My_UARTMessage_Receive(Res);
	} 
#endif
#if USART1_IT_IDLE>0
	if(USART_GetITStatus(USART1, USART_IT_IDLE) != RESET)
	{
		Res=USART1->SR;
		Res=USART1->DR;
		Res = RX_Buff_LEN - DMA_GetCurrDataCounter(DMA1_Channel5);
		memcpy(readBuffer,USART1_RX_Buff,Res);
		readMsgFlag = true;
		My_DMA_Enable(DMA1_Channel5,RX_Buff_LEN);
		LED1 = !LED1;
	}
#endif
} 
#endif

#if EN_USART2   
void USART2_IRQHandler(void)                
{
	u8 Res;
	if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)  
	{
		Res = USART_ReceiveData(USART2);	

	} 
} 
#endif

#if EN_USART3     
void USART3_IRQHandler(void)                
{
	u8 Res;
	if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET) 
	{
		Res = USART_ReceiveData(USART3);	
	} 
} 
#endif

