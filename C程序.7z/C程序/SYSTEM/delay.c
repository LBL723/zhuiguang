#include "delay.h"
void DWT_Init(void)
{
	CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
	DWT->CYCCNT = 0u;
	DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

void delay_us(u32 usCount)
{
    u32 tCnt, tDelayCnt;
	u32 tStart;
		
	tStart = DWT->CYCCNT;                                     
	tCnt = 0;
	tDelayCnt = usCount * (SystemCoreClock / 1000000)-32;	 	      

	while(tCnt < tDelayCnt)
	{
		tCnt = DWT->CYCCNT - tStart; 
	}
}

void delay_ms(u16 msCount)
{
	delay_us(msCount*1000);
}

void delay_sec(u8 secCount)
{
	while(secCount)
	{
		delay_ms(1000);
		secCount--;
	}
}

